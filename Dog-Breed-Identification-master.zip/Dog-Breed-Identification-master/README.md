# Dog Breed Identification



## Data

The dataset was downloaded from [Kaggle](https://www.kaggle.com/c/dog-breed-identification/data), which comprises 120 breeds of dogs
- train.zip: the training set, 10222 dog images
- test.zip: the test set, 10357 dog images
- labels.csv.zip: the labels (dog breeds) for the images in the training set
- sample_submission.csv.zip: a sample submission file in the correct format




